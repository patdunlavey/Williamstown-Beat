$Id: README.txt,v 1.1.4.4 2009/05/01 13:31:10 alexb Exp $

Feed Element Mapper
===================

About
=====

Add-on module for FeedAPI that maps elements on a feed item such as tags or the 
author name to taxonomy or CCK fields. These mappings are configurable by point 
and click.

Documentation
=============

For implementing mappers refer to API documentation in feedapi_mapper.api.php

Tutorials
=========

Blog post with screen cast explaining how to use Feed Element Mapper.

http://www.developmentseed.org/blog/2007/oct/30/pick-it-feed-stick-it-node